import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import threading
import ollama
import subprocess
import json  
import pygame
import webbrowser 
import tkinter.filedialog as filedialog
from PyPDF2 import PdfReader
import docx
import pandas as pd
from PIL import Image as PILImage
import os
from charset_normalizer import detect
from PIL import ImageDraw  
import pickle  
import datetime  

# Initialize pygame mixer
pygame.mixer.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
CHATBOX_WIDTH = int(WINDOW_WIDTH * 0.8)  # Fixed width for chat area
MESSAGE_MAX_WIDTH = int(CHATBOX_WIDTH)  # Wrap text at 3/4 width

SAVED_CONVERSATIONS_FILE = "saved_conversations.json"  # File to store saved conversations

def analyze_images(path, model_name):
    if not model_name:
        raise ValueError("No model name provided.")

    if os.path.isfile(path) and path.lower().endswith(('.png', '.jpg', '.jpeg')):
        try:
            # Use subprocess to call ollama run with image path
            result = subprocess.run(
                ["ollama", "run", model_name, "-i", path],
                capture_output=True,
                text=True,
                check=True
            )
            output = result.stdout.strip()
            return {os.path.basename(path): output}
        except Exception as e:
            print(f"Error analyzing image: {e}")  # Log the error
            return {os.path.basename(path): f"Error analyzing image: {e}"}
    else:
        raise ValueError(f"The path '{path}' is not a valid image file.")


# Global button style function
def create_custom_button(master, text, command, **kwargs):
    # Create and return a CustomTkinter button
    return ctk.CTkButton(
        master,
        text=text,
        command=command,
        fg_color="#1f239e",        # Dark red background
        text_color="white",        # White text color
        corner_radius=15,          # Rounded corners
        hover_color="#003f75",     # Darker color on hover
        **kwargs                   # Accept additional keyword arguments
    )

class ChatApplication:
    def __init__(   self):
        # Initialize the main window and settings
        self.root = ctk.CTk()
        self.settings = self.load_settings()
        self.bot_response_thread = None  # Track the bot response thread
        self.stop_response_flag = threading.Event()  # Event to signal stopping the bot response
        self.chat_labels = []  # Store references to chat labels
        self.attached_file_content = None  # Store content of the attached file
        self.conversation_history = []  # Store the conversation history
        self.saved_conversations = {}  # Store saved conversations
        self.setup_ui()

    def load_settings(self):
        # Load settings from file or use defaults
        try:
            with open(SETTINGS_FILE, "r") as file:
                loaded_settings = json.load(file)
                # Merge missing keys from DEFAULT_SETTINGS
                for key, value in DEFAULT_SETTINGS.items():
                    if key not in loaded_settings:
                        loaded_settings[key] = value
                return loaded_settings
        except (FileNotFoundError, json.JSONDecodeError):
            return DEFAULT_SETTINGS.copy()

    def ensure_model_selected(self):
        # Ensure a model is selected, prompt user if not
        model_name = self.settings.get("model_name")
        if not model_name:
            self.prompt_model_selection()
            return

        # Run the selected model
        try:
            subprocess.Popen(["ollama", "run", model_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start model: {e}")

    def prompt_model_selection(self):
        # Prompt user to select a model if none is set
        available_models = self.fetch_available_models()
        if not available_models:
            messagebox.showerror("Error", "No models available. Please ensure models are installed.")
            self.root.destroy()
            return

        def on_model_select(selected_model):
            # Save and use the selected model
            self.settings["model_name"] = selected_model
            self.save_settings()
            selection_window.destroy()
            self.ensure_model_selected()

        selection_window = ctk.CTkToplevel(self.root)
        selection_window.title("Select Model")
        selection_window.geometry("300x150")
        selection_window.attributes("-topmost", True)

        ctk.CTkLabel(selection_window, text="Please select a model:", font=("arial", 12)).pack(pady=10)
        model_dropdown = ctk.CTkOptionMenu(
            selection_window,
            values=available_models,
            command=on_model_select
        )
        model_dropdown.pack(pady=10)
        model_dropdown.set(available_models[0])  # Set default selection

    def fetch_available_models(self):
        # Fetch available models using "ollama ls"
        try:
            result = subprocess.run(["ollama", "ls"], capture_output=True, text=True, check=True)
            models = [line.split()[0] for line in result.stdout.strip().splitlines() if line.split()[0] != "NAME"]  # Exclude "Name"
            return models
        except Exception as e:
            messagebox.showwarning("Warning", f"No models available: {e}")
            return []  # Fallback to an empty list

    def setup_ui(self):
        # Setup the UI components
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.minsize(750, 500)  # Set minimum window size
        self.root.title("Monis")
        icon_path = os.path.join(os.path.dirname(__file__), "resources", "b.ico")
        self.root.iconbitmap(icon_path)  # Set window icon

        # Add the "Mode" button with icon
        mode_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lmode.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dmode.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.mode_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=mode_icon,  # Use icon instead of text
            corner_radius=3,
            text="",
            hover_color="#ffffff",
            command=self.toggle_mode
        )
        self.mode_button.place(x=6, y=10)

        # Add the "New Chat" button with icon
        new_chat_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lnew_chat.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dnew_chat.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.new_chat_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=new_chat_icon,  # Use icon instead of text
            corner_radius=3,
            text="",
            hover_color="#ffffff",
            command=self.new_chat
        )
        self.new_chat_button.place(x=6, y=50)

        # Add the "Help" button with icon
        help_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lhelp.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dhelp.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.help_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=help_icon,  # Use icon instead of text
            corner_radius=3,
            hover_color="#ffffff",
            text="",
            command=self.open_help
        )
        self.help_button.place(x=6, y=170)

        # Add the "Settings" button with icon
        settings_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lsettings.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dsettings.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.settings_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=settings_icon,  # Use icon instead of text
            corner_radius=3,
            text="",
            hover_color="#ffffff",
            command=self.open_settings
        )
        self.settings_button.place(x=6, y=130)

        # Add the "Save" button with icon
        save_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lsave.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dsave.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.save_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=save_icon,
            corner_radius=3,
            text="",
            hover_color="#ffffff",
            command=self.show_saved_conversations
        )
        self.save_button.place(x=6, y=90)

        # Main chat container (fixed width)
        self.chat_frame = ctk.CTkScrollableFrame(self.root, width=CHATBOX_WIDTH)
        self.chat_frame.pack(fill="both", expand=True, padx=(40, 20), pady=5)

        # Entry field and send button
        self.entry_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        self.entry_frame.pack(fill="x", padx=20, pady=5)

        self.entry_box = ctk.CTkEntry(self.entry_frame, placeholder_text="write your message in here", fg_color="#ffffff", corner_radius=15, border_width=0) 
        self.entry_box.pack(side="left", padx=(20, 0), pady=5, fill="x", expand=True)  # Added fill="x" and expand=True

        # Load the stop icon
        stop_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lstop.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dstop.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )

        # Send button
        self.send_button = create_custom_button(
            self.entry_frame, 
            text="Send", 
            command=lambda: self.send_message(), 
            width=80, 
            height=30
        )
        self.send_button.pack(side="right", padx=5, pady=5)  # Adjusted padding for swapping

        # Stop button (initially hidden)
        self.stop_button = ctk.CTkButton(
            self.entry_frame,
            width=80,
            height=30,
            bg_color="transparent",
            fg_color="#c52626",
            image=stop_icon,
            text="",
            corner_radius=15,
            hover_color="#751A3F",
            command=self.stop_bot_response
        )
        self.stop_button.pack(side="right", padx=5, pady=5)
        self.stop_button.pack_forget()  # Hide the stop button initially

        self.entry_box.bind("<Return>", lambda event: self.send_message())

        # Add an "Attach" button with an icon
        attach_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dattach.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lattach.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.attach_button = ctk.CTkButton(
            self.entry_frame,
            width=10,
            height=10,
            fg_color="transparent",
            image=attach_icon,
            corner_radius=5,
            text="",
            hover_color="#ffffff",
            command=self.attach_file
        )
        self.attach_button.pack(side="right", padx=0, pady=5)  # Adjusted padding for swapping

        # Create a "Back" button icon
        back_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lback.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dback.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )
        self.back_button = ctk.CTkButton(
            self.root,
            width=10,
            height=10,
            fg_color="transparent",
            image=back_icon,  # Use icon instead of text
            corner_radius=3,
            hover_color="#ffffff",
            text="",
            command=self.show_chat_interface
        )
        self.back_button.place_forget()  # Hide the back button initially

        # Create the settings frame
        self.settings_frame = ctk.CTkFrame(self.root, fg_color="transparent")

        # Create the help frame
        self.help_frame = ctk.CTkFrame(self.root, fg_color="transparent")

        # Create the saved conversations frame
        self.saved_frame = ctk.CTkFrame(self.root, fg_color="transparent")

        # Add a tab view to the help frame
        help_tabview = ctk.CTkTabview(self.help_frame, fg_color="transparent", segmented_button_selected_color="#1f239e", corner_radius=10)
        help_tabview.pack(fill="both", expand=True, padx=0, pady=0)

        help_file_path = os.path.join(os.path.dirname(__file__), "resources", "help.txt")
        try:
            with open(help_file_path, "r", encoding="utf-8") as file:
                help_text = file.read()
        except FileNotFoundError:
            help_text = "Help file not found. Please ensure the file exists at the specified path."

        # Add "Help" tab
        help_tab = help_tabview.add("Help")
        help_scroll_frame = ctk.CTkScrollableFrame(help_tab, fg_color="light gray")  # Scrollable frame with light gray background
        help_scroll_frame.pack(fill="both", expand=True, padx=0, pady=0)
        ctk.CTkLabel(help_scroll_frame, text=help_text, justify="left", wraplength=640, font=("Arial", 12), text_color="black").pack(padx=0, pady=10)

        about_file_path = os.path.join(os.path.dirname(__file__), "resources", "about.txt")
        try:
            with open(about_file_path, "r") as file:
                about_text = file.read()
        except FileNotFoundError:
            about_text = "About file not found. Please ensure the file exists at the specified path."
        # Add "About" tab
        about_tab = help_tabview.add("About")
        about_scroll_frame = ctk.CTkScrollableFrame(about_tab, fg_color="light gray")  # Scrollable frame with light gray background
        about_scroll_frame.pack(fill="both", expand=True, padx=0, pady=0)
        ctk.CTkLabel(about_scroll_frame, text=about_text, justify="left", wraplength=640, font=("Arial", 12), text_color="black").pack(padx=0, pady=10)

        # Update the "Settings" button to show the settings frame
        self.settings_button.configure(command=self.show_settings)

        # Update the "Help" button to show the help frame
        self.help_button.configure(command=self.show_help)

        # Add a fixed "Contact Support" button in the help_scroll_frame
        contact_support_button = ctk.CTkButton(
            help_scroll_frame,
            text="Contact Support",
            fg_color="#1f239e",
            text_color="white",
            corner_radius=15,
            width=150,
            height=30,
            hover_color="#003f75",
            command=lambda: webbrowser.open("mailto:fahimshahi4818@gmail.com")
        )
        contact_support_button.place(relx=0.5, rely=1.0, anchor="center", y=-15)  # Fixed position at the bottom of the frame

        # Fetch available models for the dropdown
        available_models = self.fetch_available_models()
        self.model_var = tk.StringVar(value=self.settings["model_name"])

        # Settings UI components
        self.sound_var = tk.BooleanVar(value=self.settings["sound_notifications"])
        self.font_size_var = tk.IntVar(value=self.settings["font_size"])

        ctk.CTkLabel(self.settings_frame, text="Model Selection:").place(relx=0.2, rely=0.10, anchor="w")
        model_dropdown = ctk.CTkOptionMenu(
            self.settings_frame, 
            variable=self.model_var, 
            values=available_models,
            command=self.on_model_select  # Use the class method
        )
        model_dropdown.place(relx=0.6, rely=0.10, anchor="w")

        ctk.CTkLabel(self.settings_frame, text="Creativity:").place(relx=0.20, rely=0.20, anchor="w")
        self.temperature_slider = ctk.CTkSlider(self.settings_frame, from_=0.0, to=1.0, number_of_steps=100, command=lambda v: self.settings.update({"temperature": float(v)}))
        self.temperature_slider.set(self.settings["temperature"])
        self.temperature_slider.place(relx=0.6, rely=0.20, anchor="w")

        ctk.CTkLabel(self.settings_frame, text="Response length:").place(relx=0.20, rely=0.30, anchor="w")
        self.max_tokens_entry = ctk.CTkEntry(self.settings_frame)
        self.max_tokens_entry.insert(0, str(self.settings["max_tokens"]))
        self.max_tokens_entry.place(relx=0.6, rely=0.30, anchor="w")

        ctk.CTkLabel(self.settings_frame, text="Sound Notifications:").place(relx=0.20, rely=0.40, anchor="w")
        sound_checkbox = ctk.CTkCheckBox(self.settings_frame, variable=self.sound_var, text="", command=lambda: self.settings.update({"sound_notifications": self.sound_var.get()}))
        sound_checkbox.place(relx=0.67, rely=0.40, anchor="center")

        reset_button = create_custom_button(self.settings_frame, text="Reset to Defaults", command=self.reset_to_defaults)
        reset_button.place(relx=0.48, rely=0.80, anchor="center")

        # Add "Change Avatar" button in settings
        change_avatar_button = create_custom_button(
            self.settings_frame,
            text="Change User Avatar",
            command=self.change_avatar,
            width=150,
            height=30
        )
        change_avatar_button.place(relx=0.48, rely=0.50, anchor="center")

        # Load the copy icon
        self.copy_icon = ctk.CTkImage(
            light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "lcopy.png")).resize((30, 30), Image.Resampling.LANCZOS),
            dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dcopy.png")).resize((30, 30), Image.Resampling.LANCZOS)
        )

        # Load the user avatar from settings
        self.load_user_avatar()

        # Load saved conversations
        self.saved_conversations = self.load_saved_conversations()

        self.ensure_model_selected()

    def toggle_mode(self):
        # Function to toggle dark and light mode
        current_mode = ctk.get_appearance_mode().lower()
        new_mode = "light" if current_mode == "dark" else "dark"

        ctk.set_appearance_mode(new_mode)

        # Update hover colors based on the mode
        hover_color = "#000000" if new_mode == "dark" else "#ffffff"  # Black for dark mode, white for light mode
        for button in [self.mode_button, self.new_chat_button, self.help_button, self.settings_button, self.back_button, self.attach_button, self.save_button]:
            button.configure(hover_color=hover_color)

        # Update entry box color based on the mode
        entry_fg_color = "#333333" if new_mode == "dark" else "#ffffff"  # Dark gray for dark mode, white for light mode
        self.entry_box.configure(fg_color=entry_fg_color)

        # Update text color of all chat labels, bubble colors, and avatar frame colors
        new_text_color = "#000000" if new_mode == "light" else "#ffffff"
        for label in self.chat_labels:
            # Saved/loaded AI messages (plain text without a bubble)
            if not (isinstance(label.master, ctk.CTkFrame) and label.master.cget("fg_color") != "transparent"):
                label.configure(text_color=new_text_color)
            else:
                label.configure(text_color=new_text_color)
                parent_frame = label.master  # Get the bubble frame
                bubble_color = "#f0f8ff" if new_mode == "light" else "#4d514e"
                parent_frame.configure(fg_color=bubble_color)
                # Update avatar frame colors
                avatar_frame = parent_frame.master.winfo_children()[0]  # Get the avatar frame
                if isinstance(avatar_frame, ctk.CTkFrame):
                    avatar_fg_color = "white" if new_mode == "light" else "#4d514e"
                    avatar_frame.configure(fg_color=avatar_fg_color)

    def open_settings(self):
        # Function to open settings window
        settings_window = ctk.CTkToplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("400x300")
        settings_window.attributes("-topmost", True)  # Always on top
        ctk.CTkLabel(settings_window, text="Settings Window").pack(pady=20)

    def open_help(self):
        # Function to open help window with tabs
        help_window = ctk.CTkToplevel(self.root)
        help_window.title("Help")
        help_window.geometry("400x300")
        help_window.attributes("-topmost", True)  # Always on top

        tabview = ctk.CTkTabview(help_window)
        tabview.pack(fill="both", expand=True)

        help_tab = tabview.add("Help")
        about_tab = tabview.add("About")

    def new_chat(self):
        # Function to confirm and clear all chat
        def confirm_clear():
            self.conversation_history.clear()  # Clear the conversation history
            for widget in self.chat_frame.winfo_children():
                widget.destroy()  # Clear all messages from the chat frame
            self.chat_labels.clear()  # Clear the list of chat labels
            confirmation_window.destroy()

        def cancel_clear():
            confirmation_window.destroy()

        # Create a confirmation dialog
        confirmation_window = ctk.CTkToplevel(self.root)
        confirmation_window.title("Confirm clearing the chat")
        confirmation_window.geometry("350x150")
        confirmation_window.iconbitmap(None) 
        confirmation_window.attributes("-topmost", True)  # Always on top

        ctk.CTkLabel(
            confirmation_window,
            text="Are you sure you want to start a new chat and clear all current chats?",
            wraplength=250,
            justify="center"
        ).pack(pady=20)

        button_frame = ctk.CTkFrame(confirmation_window, fg_color="transparent")
        button_frame.pack(pady=10)

        confirm_button = ctk.CTkButton(
            button_frame,
            text="Yes, clear all chat",
            command=confirm_clear,
            width=120,
            height=30,
            corner_radius=15,
            hover_color="red",  # Darker color on hover
            fg_color="#A40000",  # Example: Red background color
            text_color="#ffffff"
        ).pack(side="left", padx=10)

        create_custom_button(
            button_frame,
            text="Cancel",
            command=cancel_clear,
            width=80,
            height=30
        ).pack(side="right", padx=10)
        
    def attach_file(self):
        # Function to handle file attachment
        file_path = filedialog.askopenfilename(
            filetypes=[
                ("PDF files", "*.pdf"),
                ("Word files", "*.docx"),
                ("Excel files", "*.xlsx"),
                ("CSV files", "*.csv"),
                ("Image files", "*.png;*.jpg;*.jpeg"),
            ]
        )
        if not file_path:
            return

        try:
            print(f"File selected: {file_path}")  # Debugging log
            model_name = self.settings.get("model_name")
            if not model_name:
                self.add_message("No model selected. Please select a model in settings.", "assistant")
                return

            if file_path.lower().endswith((".png", ".jpg", ".jpeg")):
                print("Analyzing image...")  # Debugging log
                # Pass the file path to analyze_images
                analysis_result = analyze_images(file_path, model_name)
                content = analysis_result.get(os.path.basename(file_path), "Error analyzing image.")
                print(f"Image analysis result: {content}")  # Debugging log
            elif file_path.endswith(".csv"):
                # Automatically detect encoding
                with open(file_path, 'rb') as f:
                    result = detect(f.read())
                    detected_encoding = result['encoding']
                df = pd.read_csv(file_path, encoding=detected_encoding)
                content = df.to_string()
            elif file_path.endswith(".xlsx"):
                df = pd.read_excel(file_path)
                content = df.to_string()
            elif file_path.endswith(".pdf"):
                reader = PdfReader(file_path)
                content = " ".join(page.extract_text() for page in reader.pages)
            elif file_path.endswith(".docx"):
                doc = docx.Document(file_path)
                content = " ".join(paragraph.text for paragraph in doc.paragraphs)
            else:
                content = "Unsupported file format."

            self.attached_file_content = f"[A file is attached...***]\n{content}\n[***]"
            self.show_notification("File attached successfully!")

        except Exception as e:
            print(f"Error processing file: {e}")  # Debugging log
            self.add_message(f"Error processing file: {e}", "assistant")

    def view_attached_file(self):
        # Function to display the attached file content in a new window
        if not self.attached_file_content:
            messagebox.showinfo("No File", "No file content to display.")
            return

        # Create a new window to display the file content
        file_window = ctk.CTkToplevel(self.root)
        file_window.title("Attached File Content")
        file_window.geometry("600x400")
        file_window.attributes("-topmost", True)

        # Add a scrollable text widget to display the content
        text_widget = ctk.CTkScrollableFrame(file_window, fg_color="white")
        text_widget.pack(fill="both", expand=True, padx=10, pady=10)

        ctk.CTkLabel(
            text_widget,
            text=self.attached_file_content,
            justify="left",
            wraplength=580,
            font=("Arial", 12),
            text_color="black"
        ).pack(padx=10, pady=10)

    def show_notification(self, message):
        # Create a temporary notification label at the top of the window
        notification = ctk.CTkLabel(
            self.root,
            text=message,
            fg_color="#1f239e",
            bg_color="transparent",
            text_color="white",
            corner_radius=5,
            font=("Arial", 12)
        )
        notification.place(relx=0.5, rely=0.05, anchor="center")  # Position at the top center

        # Bind the notification click to view the attached file
        if "File attached successfully!" in message:
            notification.bind("<Button-1>", lambda event: self.view_attached_file())
            notification.configure(cursor="hand2")  # Change cursor to hand to indicate clickability

        # Remove the notification after 2 seconds
        self.root.after(2000, notification.destroy)

    def show_notification(self, message):
        # Create a temporary notification label at the top of the window
        notification = ctk.CTkLabel(
            self.root,
            text=message,
            fg_color="#1f239e",
            bg_color="transparent",
            text_color="white",
            corner_radius=5,
            font=("Arial", 12)
        )
        notification.place(relx=0.5, rely=0.05, anchor="center")  # Position at the top center

        # Bind the notification click to view the attached file
        if "File attached successfully!" in message:
            notification.bind("<Button-1>", lambda event: self.view_attached_file())

        # Remove the notification after 2 seconds
        self.root.after(2000, notification.destroy)

    def copy_to_clipboard(self, text):
        # Function to copy text to clipboard and show notification
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()  # Update the clipboard
        self.show_notification("Copied to clipboard!")  # Show notification

    def add_message(self, text, sender, update_history=True, is_saved=False):
        # Modify the add_message function to optionally skip updating conversation_history
        text = text.strip()
        if not text:
            return

        is_user = sender == "user"
        appearance_mode = ctk.get_appearance_mode()
        
        # Set bubble color based on appearance mode
        if (appearance_mode == "Light"):
            bubble_color = "#f0f8ff" if is_user else self.settings["bot_bubble_color"]
        else:  # Dark mode
            bubble_color = "#4d514e" if is_user else self.settings["bot_bubble_color"]

        # Define the anchor side based on the sender
        anchor_side = "e" if is_user else "w"

        # Independent wrapper with fixed width
        message_wrapper = ctk.CTkFrame(self.chat_frame, width=CHATBOX_WIDTH, fg_color="transparent")
        message_wrapper.pack(fill="x", expand=True)

        # Skip creating a bubble for saved AI messages
        if sender == "assistant" and is_saved:
            label = ctk.CTkLabel(
                message_wrapper,
                text=text,
                wraplength=MESSAGE_MAX_WIDTH,
                justify="left",
                text_color="#000000" if appearance_mode == "Light" else "#ffffff"
            )
            label.pack(anchor="w", padx=10, pady=(10, 0))
            self.chat_labels.append(label)  # Store reference to the label
        else:
            # Bubble inside wrapper
            bubble_frame = ctk.CTkFrame(message_wrapper, fg_color=bubble_color, corner_radius=15)

            # Label to hold the message text
            label = ctk.CTkLabel(bubble_frame, text=text, wraplength=MESSAGE_MAX_WIDTH, justify="left")
            label.pack(padx=5, pady=3)
            self.chat_labels.append(label)  # Store reference to the label

            # Create a container frame for both the label and the image
            avatar_frame = ctk.CTkFrame(message_wrapper, width=40, height=40, corner_radius=20, fg_color="transparent")
            avatar_frame.pack(side="right" if is_user else "left", padx=0, pady=0)

            # Load the user image based on the appearance mode
            user_image = Image.open(os.path.join(os.path.dirname(__file__), "resources", "lusernew.png")).resize((40, 40), Image.Resampling.LANCZOS)
            # Place the message bubble accordingly
            bubble_frame.pack(anchor=anchor_side, padx=5, pady=10)
            # Define avatars using Pillow and resize them

            user_image = user_image.resize((40, 40), Image.Resampling.LANCZOS)
            user_avatar = ctk.CTkImage(user_image, size=(30, 30))
            
            # Create the avatar image with fixed size inside the avatar frame
            avatar_image = ctk.CTkLabel(avatar_frame, image=self.user_avatar, text="", width=60, height=60, fg_color="transparent")

            avatar_image.place(relx=0.48, rely=0.48, anchor="center")

        # Add to conversation history with valid roles
        if update_history:
            if sender == "user":
                self.conversation_history.append({"role": "user", "content": text})
            elif sender == "assistant":
                self.conversation_history.append({"role": "assistant", "content": text})

        self.chat_frame.update_idletasks()
        self.chat_frame._parent_canvas.yview_moveto(1)  # Scroll to the bottom

    def send_message(self):
        # Function to send user message and bot reply
        user_text = self.entry_box.get()
        if user_text or self.attached_file_content:
            # Display only the user message in the chat
            self.add_message(user_text, "user")
            self.entry_box.delete(0, "end")

            self.stop_response_flag.clear()  # Reset the stop flag
            self.send_button.pack_forget()  # Hide the send button
            self.attach_button.pack_forget()  # Hide the attach button
            self.stop_button.pack(side="right", padx=5, pady=5)  # Show the stop button
            self.bot_response_thread = threading.Thread(target=self.get_ollama_response)
            self.bot_response_thread.start()

    def stop_bot_response(self):
        # Function to stop the bot's response
        self.stop_response_flag.set()  # Signal the bot response to stop
        self.stop_button.pack_forget()  # Hide the stop button
        self.attach_button.pack_forget()  # Show the attach button
        self.send_button.pack(side="right", padx=5, pady=5)  # Show the send button

    def open_response_editor(self, response_text):
        # Function to open a new window for editing or copying the AI response
        editor_window = ctk.CTkToplevel(self.root)
        editor_window.title("Edit Response")
        editor_window.geometry("600x500")
        editor_window.attributes("-topmost", True)

        # Add a text widget for editing the response
        text_widget = tk.Text(editor_window, wrap="word", font=("Arial", 12))
        text_widget.pack(fill="both", expand=True, padx=10, pady=10)
        text_widget.insert("1.0", response_text)  # Insert the response text

        # Add a button to copy the edited text to the clipboard
        def copy_edited_text():
            self.root.clipboard_clear()
            self.root.clipboard_append(text_widget.get("1.0", "end").strip())
            self.root.update()  # Update the clipboard
            self.show_notification("Edited response copied to clipboard!")

        copy_button = ctk.CTkButton(
            editor_window,
            text="Copy to Clipboard",
            command=copy_edited_text,
            fg_color="#1f239e",
            text_color="white",
            corner_radius=15,
            width=150,
            height=30,
            hover_color="#003f75"
        )
        copy_button.pack(pady=10)

    def get_ollama_response(self):
        # Use the currently selected model to generate a response
        model_name = self.settings.get("model_name")
        if not model_name:
            self.add_message("No model selected. Please select a model in settings.", "assistant")
            return

        appearance_mode = ctk.get_appearance_mode()
        try:
            # Stream the response from Ollama with conversation history
            stream = ollama.chat(model=model_name, messages=self.conversation_history, stream=True)
            response_text = ""
            live_response_label = ctk.CTkLabel(
                self.chat_frame,
                text="",
                wraplength=MESSAGE_MAX_WIDTH,
                justify="left",
                text_color="#ffffff" if appearance_mode == "Dark" else "#000000"
            )
            live_response_label.pack(anchor="w", padx=10, pady=(10, 0))
            self.chat_labels.append(live_response_label)  # Store reference to the label

            for chunk in stream:
                if self.stop_response_flag.is_set():  # Check if stop is requested
                    break
                response_text += chunk['message']['content']
                live_response_label.configure(text=response_text.strip())
                self.chat_frame.update_idletasks()

            if not self.stop_response_flag.is_set():
                # Add bot response to conversation history with the correct role
                self.conversation_history.append({"role": "assistant", "content": response_text.strip()})

                # Create a container for the copy and edit buttons
                button_container = ctk.CTkFrame(self.chat_frame, fg_color="transparent")
                button_container.pack(anchor="w", padx=5, pady=(0, 10))  # Fixed position under the response

                # Copy button
                copy_button = ctk.CTkButton(
                    button_container,
                    image=self.copy_icon,
                    fg_color="transparent",
                    text="",
                    hover=None,
                    width=3,
                    height=3,
                    command=lambda: self.copy_to_clipboard(response_text.strip())
                )
                copy_button.pack(side="left", padx=0)

                # Edit button
                edit_icon = ctk.CTkImage(
                    light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "ledit.png")).resize((50, 50), Image.Resampling.LANCZOS),
                    dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "dedit.png")).resize((50, 50), Image.Resampling.LANCZOS)
                )
                edit_button = ctk.CTkButton(
                    button_container,
                    image=edit_icon,
                    fg_color="transparent",
                    text="",
                    hover=None,
                    width=3,
                    height=3,
                    command=lambda: self.open_response_editor(response_text.strip())
                )
                edit_button.pack(side="left", padx=0)

            if self.settings.get("sound_notifications", True) and not self.stop_response_flag.is_set():
                pygame.mixer.music.load(os.path.join(os.path.dirname(__file__), "resources", "noti.wav"))
                pygame.mixer.music.play()
            self.chat_frame._parent_canvas.yview_moveto(1)  # Scroll to the bottom
        except Exception as e:
            self.add_message(f"Error: {e}", "assistant")

        finally:
            self.stop_button.pack_forget()  # Hide the stop button when response ends
            self.attach_button.pack(side="left", padx=0, pady=5)  # Show the attach button
            self.send_button.pack(side="right", padx=5, pady=5)  # Show the send button

    def show_chat_interface(self):
        # Function to switch to the main chat interface
        self.settings_frame.pack_forget()
        self.help_frame.pack_forget()
        self.saved_frame.pack_forget()
        self.back_button.place_forget()  # Hide the back button
        self.new_chat_button.place(x=6, y=50)  # Show the new chat button
        self.chat_frame.pack(fill="both", expand=True, padx=(40, 20), pady=5)
        self.entry_frame.pack(fill="x", padx=20, pady=5)
        self.settings_button.place(x=6, y=130)
        self.help_button.place(x=6, y=170)
        self.save_button.place(x=6, y=90)

    def show_settings(self):
        # Function to show the settings frame
        self.chat_frame.pack_forget()
        self.entry_frame.pack_forget()
        self.help_frame.pack_forget()
        self.saved_frame.pack_forget()
        self.new_chat_button.place_forget()  # Hide the new chat button
        self.back_button.place(x=6, y=10)  # Show the back button at the top
        self.settings_button.place(x=6, y=50)
        self.help_button.place(x=6, y=90)
        self.save_button.place_forget()
        self.settings_frame.pack(fill="both", expand=True, padx=(40, 20), pady=5)

    def show_help(self):
        # Function to show the help frame
        self.chat_frame.pack_forget()
        self.entry_frame.pack_forget()
        self.settings_frame.pack_forget()
        self.saved_frame.pack_forget()
        self.settings_button.place(x=6, y=50)
        self.help_button.place(x=6, y=90)
        self.save_button.place_forget()
        self.new_chat_button.place_forget()  # Hide the new chat button
        self.back_button.place(x=6, y=10)  # Show the back button at the top
        self.help_frame.pack(fill="both", expand=True, padx=(40, 20), pady=5)

    def show_saved_conversations(self):
        # Function to display saved conversations with Save and Load options
        self.chat_frame.pack_forget()
        self.entry_frame.pack_forget()
        self.settings_frame.pack_forget()
        self.help_frame.pack_forget()
        self.saved_frame.pack(fill="both", expand=True, padx=(40, 20), pady=5)
        self.back_button.place(x=6, y=10)

        # Clear previous content
        for widget in self.saved_frame.winfo_children():
            widget.destroy()

        # Add Save and Load buttons
        button_frame = ctk.CTkFrame(self.saved_frame, fg_color="transparent")
        button_frame.place(relx=0.5, rely=0.5, anchor="center")

        save_button = create_custom_button(
            button_frame,
            text="Save a message",
            command=self.open_save_frame,
            width=100,
            height=30
        )
        save_button.place(relx=0.5, rely=0.4, anchor="center")

        load_button = create_custom_button(
            button_frame,
            text="Load",
            command=self.show_saved_messages,
            width=100,
            height=30
        )
        load_button.place(relx=0.5, rely=0.6, anchor="center")

    def open_save_frame(self):
        # Function to open the save frame for entering a title and saving the conversation
        if not self.conversation_history:
            messagebox.showinfo("No Conversation", "No conversation to save.")
            return

        # Clear the saved frame and display the save UI
        for widget in self.saved_frame.winfo_children():
            widget.destroy()

        ctk.CTkLabel(self.saved_frame, text="Enter a title for this conversation:", font=("Arial", 14)).pack(pady=10)
        title_entry = ctk.CTkEntry(self.saved_frame, width=300)
        title_entry.pack(pady=5)

        def save_with_title():
            title = title_entry.get().strip()
            if not title:
                messagebox.showerror("Error", "Title cannot be empty.")
                return

            if title in self.saved_conversations:
                messagebox.showerror("Error", f"A conversation with the title '{title}' already exists.")
                return

            # Add timestamps to the conversation history
            timestamped_conversation = [
                {
                    "role": message["role"],
                    "content": message["content"],
                    "timestamp": datetime.datetime.now().isoformat()
                }
                for message in self.conversation_history
            ]
            self.saved_conversations[title] = timestamped_conversation
            self.save_saved_conversations()
            self.show_notification("Conversation saved successfully!")
            self.show_saved_conversations()

        save_button = create_custom_button(
            self.saved_frame,
            text="Save",
            command=save_with_title,
            width=100,
            height=30
        )
        save_button.pack(pady=10)

        # Bind the Enter key to the save_with_title function
        title_entry.bind("<Return>", lambda event: save_with_title())

    def show_saved_messages(self):
        # Function to display saved messages in the Load option
        for widget in self.saved_frame.winfo_children():
            widget.destroy()

        if not self.saved_conversations:
            ctk.CTkLabel(self.saved_frame, text="No saved conversations.", font=("Arial", 14)).place(relx=0.5, rely=0.5, anchor="center")
        else:
            y_offset = 50  # Initial vertical offset
            for index, (title, conversation) in enumerate(self.saved_conversations.items()):
                convo_frame = ctk.CTkFrame(self.saved_frame, fg_color="transparent")
                convo_frame.place(relx=0.5, rely=0.0, anchor="center", y=y_offset)  # Position each frame dynamically

                # Add the "Load" button
                convo_button = create_custom_button(
                    convo_frame,
                    text=title,
                    command=lambda t=title: self.load_conversation(t),
                    width=200,
                    height=30
                )
                convo_button.pack(side="left", padx=5)  # Align to the left with padding

                # Add the "Delete" button
                delete_icon = ctk.CTkImage(
                    light_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "ldelete.png")).resize((20, 20), Image.Resampling.LANCZOS),
                    dark_image=Image.open(os.path.join(os.path.dirname(__file__), "resources", "ddelete.png")).resize((20, 20), Image.Resampling.LANCZOS)
                )
                delete_button = ctk.CTkButton(
                    convo_frame,
                    image=delete_icon,
                    text="",
                    fg_color="transparent",
                    hover_color="#ffffff",
                    width=30,
                    height=30,
                    command=lambda t=title: self.delete_saved_conversation(t)
                )
                delete_button.pack(side="left", padx=5)  # Align next to the "Load" button

                y_offset += 50  # Increment vertical offset for the next frame

    def delete_saved_conversation(self, title):
        # Function to delete a saved conversation
        if title in self.saved_conversations:
            del self.saved_conversations[title]
            self.save_saved_conversations()
            self.show_saved_conversations()

    def save_saved_conversations(self):
        # Save saved conversations to a JSON file
        try:
            with open(SAVED_CONVERSATIONS_FILE, "w", encoding="utf-8") as file:
                json.dump(self.saved_conversations, file, indent=4)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save conversations: {e}")

    def load_saved_conversations(self):
        # Load saved conversations from a JSON file
        try:
            with open(SAVED_CONVERSATIONS_FILE, "r", encoding="utf-8") as file:
                return json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def reset_to_defaults(self):
        # Function to reset settings to defaults
        self.settings = DEFAULT_SETTINGS.copy()
        self.save_settings()
        self.update_settings_ui()
        ctk.CTkLabel(self.settings_frame, text="Settings reset to defaults.", text_color="green").pack(pady=5)

    def update_settings_ui(self):
        # Function to update settings UI with current settings
        self.model_var.set(self.settings["model_name"])
        self.temperature_slider.set(self.settings["temperature"])
        self.max_tokens_entry.delete(0, "end")
        self.max_tokens_entry.insert(0, str(self.settings["max_tokens"]))
        self.sound_var.set(self.settings["sound_notifications"])
        self.font_size_var.set(self.settings["font_size"])

    def on_close(self):
        # Save settings on close
        self.settings.update({
            "model_name": self.model_var.get(),
            "temperature": self.temperature_slider.get(),
            "max_tokens": int(self.max_tokens_entry.get()),
            "sound_notifications": self.sound_var.get(),
            "font_size": self.font_size_var.get(),
        })
        self.save_settings()
        self.root.destroy()

    def save_settings(self):
        # Save settings to the settings.json file
        try:
            with open(SETTINGS_FILE, "w") as file:
                json.dump(self.settings, file, indent=4)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save settings: {e}")

    def on_model_select(self, selected_model):
        # Save only the model name in settings and restart it
        self.settings["model_name"] = selected_model
        self.save_settings()
        try:
            subprocess.Popen(["ollama", "run", selected_model], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to start selected model: {e}")

    def change_avatar(self):
        # Function to change the user avatar
        file_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.png;*.jpg;*.jpeg")]
        )
        if not file_path:
            return

        try:
            # Open the image without resizing initially
            image = PILImage.open(file_path)

            # Create a circular mask based on the original image size
            size = min(image.size)  # Use the smaller dimension for the circle
            mask = PILImage.new("L", (size, size), 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, size, size), fill=255)

            # Crop the image to a square and apply the circular mask
            image = image.crop((0, 0, size, size))
            circular_image = PILImage.new("RGBA", (size, size))
            circular_image.paste(image, (0, 0), mask)

            # Resize the circular image to 1024x1024 resolution
            circular_image = circular_image.resize((1024, 1024), Image.Resampling.LANCZOS)

            # Save the circular image in the resources folder
            resources_dir = os.path.join(os.path.dirname(__file__), "resources")
            os.makedirs(resources_dir, exist_ok=True)
            avatar_path = os.path.join(resources_dir, "user_avatar.png")
            circular_image.save(avatar_path)

            # Update settings and reload the avatar
            self.settings["user_avatar"] = avatar_path
            self.save_settings()
            self.load_user_avatar()
            self.show_notification("Avatar updated successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update avatar: {e}")

    def load_user_avatar(self):
        # Function to load the user avatar from settings
        avatar_path = self.settings.get("user_avatar", os.path.join(os.path.dirname(__file__), "resources", "lusernew.png"))
        try:
            user_image = PILImage.open(avatar_path).resize((40, 40), Image.Resampling.LANCZOS)
            self.user_avatar = ctk.CTkImage(user_image, size=(30, 30))
        except Exception:
            # Fallback to default avatar if loading fails
            default_avatar_path = os.path.join(os.path.dirname(__file__), "resources", "lusernew.png")
            user_image = PILImage.open(default_avatar_path).resize((40, 40), Image.Resampling.LANCZOS)
            self.user_avatar = ctk.CTkImage(user_image, size=(30, 30))

    def load_conversation(self, title):
        # Function to load a saved conversation and display it in the chat interface
        if title not in self.saved_conversations:
            messagebox.showerror("Error", f"No conversation found with the title '{title}'.")
            return

        # Clear the current chat interface
        self.conversation_history = self.saved_conversations[title].copy()
        self.show_chat_interface()

        for widget in self.chat_frame.winfo_children():
            widget.destroy()
        self.chat_labels.clear()

        # Add messages to the chat frame
        for message in self.conversation_history:
            if message["role"] == "assistant":
                self.add_message(message["content"], "assistant", update_history=False, is_saved=True)
            elif message["role"] == "user":
                self.add_message(message["content"], "user", update_history=False)

    def run(self):
        # Run the application
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.mainloop()


# Default settings
DEFAULT_SETTINGS = {
    "temperature": 0.7,
    "max_tokens": 1000,
    "sound_notifications": True,
    "font_size": 12,
    "model_name": None,  # Default to None to ensure selection
    "bot_bubble_color": "#d1e7dd",  # Default color for bot message bubbles
    "user_avatar": None,  # Default to None to use the default avatar
}

SETTINGS_FILE = "settings.json"

# Run the application
if __name__ == "__main__":
    app = ChatApplication()
    app.run()
